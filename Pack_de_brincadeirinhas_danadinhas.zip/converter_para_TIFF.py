import os
from PIL import Image

# Pastas de entrada e saída
input_folder = "C:\\Arquivos\\arquivos_py\\xx"
output_folder = "C:\\Arquivos\\arquivos_py\\yy"

input("> ")
# Verifica se a pasta de saída existe, se não, cria
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Varre todos os arquivos JPG na pasta de entrada
files = sorted([f for f in os.listdir(input_folder) if f.endswith('.jpg')])

# Dicionário para armazenar pares de imagens
images_pairs = {}

# Organiza os arquivos em pares de frente e verso
for file in files:
    base_name = file.rsplit('-', 1)[0]  # Exemplo: "RI 1"
    side = file.rsplit('-', 1)[1].split('.')[0]  # Exemplo: "1" ou "2"
    
    if base_name not in images_pairs:
        images_pairs[base_name] = {}
    
    images_pairs[base_name][side] = file

# Processa os pares e converte para TIFF
for base_name, sides in images_pairs.items():
    if '1' in sides and '2' in sides:
        front_image_path = os.path.join(input_folder, sides['1'])
        back_image_path = os.path.join(input_folder, sides['2'])
        
        # Abre as imagens frente e verso
        front_image = Image.open(front_image_path)
        back_image = Image.open(back_image_path)
        
        # Verifica as dimensões das imagens
        width = max(front_image.width, back_image.width)
        height = front_image.height + back_image.height

        # Cria uma nova imagem para concatenar verticalmente
        combined_image = Image.new('RGB', (width, height))

        # Cola a frente e o verso na imagem combinada
        combined_image.paste(front_image, (0, 0))
        combined_image.paste(back_image, (0, front_image.height))
        
        # Salva o arquivo TIFF
        output_file = os.path.join(output_folder, f"{base_name}.tiff")
        combined_image.save(output_file)

        print(f"Arquivo {base_name}.tiff criado com sucesso.")

print("Processo concluído!")
