import os
import re

def ordenar_naturalmente(texto):
    return [int(t) if t.isdigit() else t for t in re.split(r'(\d+)', texto)]

def renomear_arquivos(pasta):
    try:
        arquivos = os.listdir(pasta)
        arquivos.sort(key=ordenar_naturalmente)

        numero_folha = 1
        
        for i, arquivo in enumerate(arquivos):
            parte = (i % 2) + 1

            novo_nome = f"NOME_DO_LIVRO {numero_folha}-{parte}.JPG" # Exemplo: RI-2A 12-1
            
            caminho_antigo = os.path.join(pasta, arquivo)
            caminho_novo = os.path.join(pasta, novo_nome)
            os.rename(caminho_antigo, caminho_novo)
            if parte == 2:
                numero_folha += 1

    except NameError:
        print("Erro --> ", NameError )

pasta = ""

renomear_arquivos(pasta)