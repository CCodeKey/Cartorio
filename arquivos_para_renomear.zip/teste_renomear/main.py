import os
import re

def ordenar_naturalmente(texto):
    return [int(t) if t.isdigit() else t for t in re.split(r'(\d+)', texto)]

def renomear_arquivos(pasta):
    # Lista todos os arquivos na pasta
    arquivos = os.listdir(pasta)
    
    # Ordena os arquivos naturalmente
    arquivos.sort(key=ordenar_naturalmente)

    # Inicializa um contador de páginas
    numero_folha = 1
    
    # Itera sobre os arquivos
    for i, arquivo in enumerate(arquivos):
        # Define o novo nome para a parte frontal e verso
        parte = (i % 2) + 1
        novo_nome = f"PR-1F {numero_folha}-{parte}.jpg"
        
        # Caminhos completos dos arquivos
        caminho_antigo = os.path.join(pasta, arquivo)
        caminho_novo = os.path.join(pasta, novo_nome)
        
        # Renomeia o arquivo
        os.rename(caminho_antigo, caminho_novo)
        
        # Incrementa o contador de páginas a cada duas iterações
        if parte == 2:
            numero_folha += 1

# Caminho da pasta
pasta = 'C:\\pasta_de_teste\\teste_renomear\\Remessa'

# Chama a função
renomear_arquivos(pasta)
